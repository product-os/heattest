__author__ = "Nico Schlömer"
__email__ = "nico.schloemer@gmail.com"
__copyright__ = "Copyright (c) 2017-2019, {} <{}>".format(__author__, __email__)
__license__ = "License :: OSI Approved :: MIT License"
__version__ = "0.2.2"
__maintainer__ = "Nico Schlömer"
__status__ = "Development Status :: 4 - Beta"
