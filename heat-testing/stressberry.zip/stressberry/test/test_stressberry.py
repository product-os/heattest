import stressberry


def test_stressberry():
    stressberry.stress_cpu(1, 5)
    return
